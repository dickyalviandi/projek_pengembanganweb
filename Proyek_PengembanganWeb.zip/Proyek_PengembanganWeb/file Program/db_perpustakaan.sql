-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 17 Jan 2025 pada 13.40
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_perpustakaan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `buku`
--

CREATE TABLE `buku` (
  `id_buku` int(11) NOT NULL,
  `judul_buku` varchar(125) NOT NULL,
  `kategori_buku` varchar(125) NOT NULL,
  `penerbit_buku` varchar(125) NOT NULL,
  `pengarang` varchar(125) NOT NULL,
  `tahun_terbit` varchar(125) NOT NULL,
  `isbn` int(50) NOT NULL,
  `j_buku_baik` varchar(125) NOT NULL,
  `j_buku_rusak` varchar(125) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `buku`
--

INSERT INTO `buku` (`id_buku`, `judul_buku`, `kategori_buku`, `penerbit_buku`, `pengarang`, `tahun_terbit`, `isbn`, `j_buku_baik`, `j_buku_rusak`) VALUES
(1, 'Pemrograman Dasar', 'Buku Pelajaran', 'erlangga', 'Taufik', '2021', 6, '20', '10'),
(2, 'Sejarah Nasional Indonesia Jilid VI', 'Cerita Sejarah', 'Balai Pustaka', 'Nugroho Noto Susanto', '2001', 563367, '10', '5'),
(3, 'Indonesia Dalam Arus Sejarah', 'Cerita Sejarah', 'Kemedikbud RI', 'Taufik Abdullah', '2012', 2147483647, '10', '5'),
(4, 'Babat Tanah Jawi', 'Cerita Sejarah', 'Balai Pustaka', 'putri', '2010', 68964397, '5', '1'),
(5, 'The Pragmatic progammer', 'Buku Pelajaran', 'Addisont weslay', 'Andrew hunt', '2001', 75380867, '15', '5'),
(6, 'Introdusction to Algorithms', 'Buku Pelajaran', 'MIT Press', 'Thomas H.Corment', '2009', 1279654, '10', '3'),
(7, 'Design Partners', 'Buku Pelajaran', 'Addisont weslay', 'Errich Gamma', '2000', 123345678, '10', '2'),
(8, 'Software Endgenering ', 'Buku Pelajaran', 'pearsond', 'Ian somemerville', '2015', 2147483647, '15', '3'),
(9, 'Clean Architecture', 'Buku Pelajaran', 'Prentice Hall', 'Robert c. Martin', '2017', 2147483647, '20', '5'),
(10, 'Rekayasa Perangkat Lunak', 'Buku Pelajaran', 'Informatika Bandung', 'Wahana Komputer', '2012', 2147483647, '15', '2');

-- --------------------------------------------------------

--
-- Struktur dari tabel `identitas`
--

CREATE TABLE `identitas` (
  `id_identitas` int(11) NOT NULL,
  `nama_app` varchar(50) NOT NULL,
  `alamat_app` text NOT NULL,
  `email_app` varchar(125) NOT NULL,
  `nomor_hp` char(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `identitas`
--

INSERT INTO `identitas` (`id_identitas`, `nama_app`, `alamat_app`, `email_app`, `nomor_hp`) VALUES
(1, 'E - Perpus', 'JL. Sungal ', 'contact@e-perpus.com', '081536167697');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(11) NOT NULL,
  `kode_kategori` varchar(50) NOT NULL,
  `nama_kategori` varchar(125) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `kode_kategori`, `nama_kategori`) VALUES
(1, 'KT-001', 'Buku Pelajaran'),
(2, 'KT-002', 'Novel'),
(3, 'KT-003', 'Majalah'),
(4, 'KT-004', 'Cerita Sejarah');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemberitahuan`
--

CREATE TABLE `pemberitahuan` (
  `id_pemberitahuan` int(11) NOT NULL,
  `isi_pemberitahuan` varchar(255) NOT NULL,
  `level_user` varchar(125) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pemberitahuan`
--

INSERT INTO `pemberitahuan` (`id_pemberitahuan`, `isi_pemberitahuan`, `level_user`, `status`) VALUES
(1, '<i class=\'fa fa-exchange\'></i> #Taufik Ramadhan Telah meminjam Buku', 'Admin', 'Belum dibaca'),
(2, '<i class=\'fa fa-repeat\'></i> #Taufik Ramadhan Telah mengembalikan Buku', 'Admin', 'Belum dibaca'),
(3, '<i class=\'fa fa-exchange\'></i> #Rizky Kurniawan Pane Telah meminjam Buku', 'Admin', 'Belum dibaca'),
(4, '<i class=\'fa fa-exchange\'></i> #Taufik Ramadhan Telah meminjam Buku', 'Admin', 'Belum dibaca'),
(5, '<i class=\'fa fa-exchange\'></i> #Taufik Ramadhan Telah meminjam Buku', 'Admin', 'Belum dibaca'),
(6, '<i class=\'fa fa-repeat\'></i> #Taufik Ramadhan Telah mengembalikan Buku', 'Admin', 'Belum dibaca'),
(7, '<i class=\'fa fa-exchange\'></i> #Taufik Ramadhan Telah meminjam Buku', 'Admin', 'Belum dibaca'),
(8, '<i class=\'fa fa-exchange\'></i> #Taufik Ramadhan Telah meminjam Buku', 'Admin', 'Belum dibaca'),
(9, '<i class=\'fa fa-repeat\'></i> #Taufik Ramadhan Telah mengembalikan Buku', 'Admin', 'Belum dibaca'),
(10, '<i class=\'fa fa-exchange\'></i> #Taufik Ramadhan Telah meminjam Buku', 'Admin', 'Belum dibaca'),
(11, '<i class=\'fa fa-exchange\'></i> #Taufik Ramadhan Telah meminjam Buku', 'Admin', 'Belum dibaca'),
(12, '<i class=\'fa fa-repeat\'></i> #Taufik Ramadhan Telah mengembalikan Buku', 'Admin', 'Belum dibaca'),
(13, '<i class=\'fa fa-repeat\'></i> #Taufik Ramadhan Telah mengembalikan Buku', 'Admin', 'Belum dibaca'),
(14, '<i class=\'fa fa-exchange\'></i> #puara Telah meminjam Buku', 'Admin', 'Belum dibaca');

-- --------------------------------------------------------

--
-- Struktur dari tabel `peminjaman`
--

CREATE TABLE `peminjaman` (
  `id_peminjaman` int(11) NOT NULL,
  `nama_anggota` varchar(125) NOT NULL,
  `judul_buku` varchar(125) NOT NULL,
  `tanggal_peminjaman` varchar(125) NOT NULL,
  `tanggal_pengembalian` varchar(50) NOT NULL,
  `kondisi_buku_saat_dipinjam` varchar(125) NOT NULL,
  `kondisi_buku_saat_dikembalikan` varchar(125) NOT NULL,
  `denda` varchar(125) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `peminjaman`
--

INSERT INTO `peminjaman` (`id_peminjaman`, `nama_anggota`, `judul_buku`, `tanggal_peminjaman`, `tanggal_pengembalian`, `kondisi_buku_saat_dipinjam`, `kondisi_buku_saat_dikembalikan`, `denda`) VALUES
(1, 'Taufik Ramadhan', 'Pemrograman Dasar', '28-12-2024', '17-01-2025', 'Baik', 'Rusak', 'Rp 20.000'),
(2, 'Rizky Kurniawan Pane', 'Indonesia Dalam Arus Sejarah', '28-12-2024', '', 'Baik', '', ''),
(3, 'Taufik Ramadhan', 'Software Endgenering ', '28-12-2024', '01-01-2025', 'Baik', 'Rusak', 'Rp 20.000'),
(4, 'Taufik Ramadhan', 'Babat Tanah Jawi', '01-01-2025', '06-01-2025', 'Baik', 'Baik', 'Tidak ada'),
(5, 'Taufik Ramadhan', 'Pemrograman Dasar', '06-01-2025', '', 'Baik', '', ''),
(6, 'Taufik Ramadhan', 'Software Endgenering ', '06-01-2025', '', 'Baik', '', ''),
(7, 'Taufik Ramadhan', 'Indonesia Dalam Arus Sejarah', '06-01-2025', '', 'Baik', '', ''),
(8, 'Taufik Ramadhan', 'Introdusction to Algorithms', '07-01-2025', '', 'Rusak', '', ''),
(9, 'puara', 'Indonesia Dalam Arus Sejarah', '17-01-2025', '', 'Baik', '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penerbit`
--

CREATE TABLE `penerbit` (
  `id_penerbit` int(11) NOT NULL,
  `kode_penerbit` varchar(125) NOT NULL,
  `nama_penerbit` varchar(50) NOT NULL,
  `verif_penerbit` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `penerbit`
--

INSERT INTO `penerbit` (`id_penerbit`, `kode_penerbit`, `nama_penerbit`, `verif_penerbit`) VALUES
(1, 'P001', 'Erlangga', 'Terverifikasi'),
(3, 'P002', 'Balai Pustaka', 'Terverifikasi'),
(4, 'P003', 'Kemedikbud RI', 'Terverifikasi'),
(5, 'P004', 'Addisont weslay', 'Terverifikasi'),
(6, 'P005', 'MIT Press', 'Terverifikasi'),
(7, 'P006', 'pearsond', 'Terverifikasi'),
(8, 'P007', 'Prentice Hall', 'Terverifikasi'),
(9, 'P008', 'Informatika Bandung', 'Terverifikasi');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesan`
--

CREATE TABLE `pesan` (
  `id_pesan` int(11) NOT NULL,
  `penerima` varchar(50) NOT NULL,
  `pengirim` varchar(50) NOT NULL,
  `judul_pesan` varchar(50) NOT NULL,
  `isi_pesan` text NOT NULL,
  `status` varchar(50) NOT NULL,
  `tanggal_kirim` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pesan`
--

INSERT INTO `pesan` (`id_pesan`, `penerima`, `pengirim`, `judul_pesan`, `isi_pesan`, `status`, `tanggal_kirim`) VALUES
(1, 'Administrator', 'Taufik Ramadhan', 'Peminjaman Buku', 'halo admin saya mau memulangkan buku', 'Sudah dibaca', '28-12-2024'),
(2, 'Ridho Armansyah', 'Taufik Ramadhan', 'buku saya hilang', 'saya nangius\r\n', 'Sudah dibaca', '07-01-2025');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `kode_user` varchar(25) NOT NULL,
  `nis` char(20) NOT NULL,
  `fullname` varchar(125) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `kelas` varchar(50) NOT NULL,
  `alamat` varchar(225) NOT NULL,
  `verif` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL,
  `join_date` varchar(125) NOT NULL,
  `terakhir_login` varchar(125) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `kode_user`, `nis`, `fullname`, `username`, `password`, `kelas`, `alamat`, `verif`, `role`, `join_date`, `terakhir_login`) VALUES
(1, '-', '-', 'Administrator', 'admin', 'admin', '-', '-', 'Iya', 'Admin', '04-05-2021', '17-01-2025 ( 19:38:47 )'),
(2, 'AP001', '', 'Taufik Ramadhan', 'taufik', 'taufik', '', '', 'Tidak', 'Anggota', '28-12-2024', '17-01-2025 ( 19:27:11 )'),
(3, 'AP002', '', 'Fani angraini', 'fani', 'fani', '', '', 'Tidak', 'Anggota', '28-12-2024', '28-12-2024 ( 11:06:55 )'),
(4, 'AP003', '', 'Fauzi Syahputra', 'fauzi', 'fauzi', '', '', 'Tidak', 'Anggota', '28-12-2024', '28-12-2024 ( 11:28:55 )'),
(5, 'AP004', '', 'Rizky Kurniawan Pane', 'rizky', 'pane', '', '', 'Tidak', 'Anggota', '28-12-2024', '28-12-2024 ( 12:01:45 )'),
(6, '-', '-', 'Ridho Armansyah', 'ridhosaurus', 'ridho123', '-', '-', 'Iya', 'Admin', '28-12-2024', '28-12-2024 ( 13:53:06 )'),
(7, 'AP005', '2303310910', 'tt', 'yty', 'uu', 'X - Administrasi Perkantoran', 'jjhjh\r\n', 'Tidak', 'Anggota', '06-01-2025', ''),
(9, 'AP006', '77677', 'puara', 'puara', 'puara', 'XI - Administrasi Perkantoran', 'jl.bunga asoka\r\n', 'Tidak', 'Anggota', '17-01-2025', '17-01-2025 ( 19:28:27 )');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id_buku`);

--
-- Indeks untuk tabel `identitas`
--
ALTER TABLE `identitas`
  ADD PRIMARY KEY (`id_identitas`);

--
-- Indeks untuk tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indeks untuk tabel `pemberitahuan`
--
ALTER TABLE `pemberitahuan`
  ADD PRIMARY KEY (`id_pemberitahuan`);

--
-- Indeks untuk tabel `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`id_peminjaman`);

--
-- Indeks untuk tabel `penerbit`
--
ALTER TABLE `penerbit`
  ADD PRIMARY KEY (`id_penerbit`);

--
-- Indeks untuk tabel `pesan`
--
ALTER TABLE `pesan`
  ADD PRIMARY KEY (`id_pesan`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `buku`
--
ALTER TABLE `buku`
  MODIFY `id_buku` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `identitas`
--
ALTER TABLE `identitas`
  MODIFY `id_identitas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `pemberitahuan`
--
ALTER TABLE `pemberitahuan`
  MODIFY `id_pemberitahuan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `peminjaman`
--
ALTER TABLE `peminjaman`
  MODIFY `id_peminjaman` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `penerbit`
--
ALTER TABLE `penerbit`
  MODIFY `id_penerbit` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `pesan`
--
ALTER TABLE `pesan`
  MODIFY `id_pesan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
